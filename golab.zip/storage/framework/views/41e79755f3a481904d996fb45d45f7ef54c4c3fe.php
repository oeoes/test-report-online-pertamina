<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biaya Uji</title>
    <style>
    @page{
        margin: 3cm 1.5cm;
    }
    .judul{
        width: 100%;
        text-align: center;
        font-size: 16px;
        font-weight: bold
    }
    .subjudul{
        width: 100%;
        text-align: center;
        font-size: 14px;
        font-weight: 650
    }
    td, th{
        padding: 5px;
        font-size: 12px
    }
    .list td, th {
        border: 1px solid #c9d6c9; 
        border-collapse: collapse;
    }
    .list{
        border: 1px solid #c9d6c9; 
        border-collapse: collapse;
        font-size: 12px;
        margin-top: 10px
    }
    p, ol {
        text-align: justify;
        font-size: 13px
    }
    .bodylist tr:nth-child(even) {background: #fff}
    .bodylist tr:nth-child(odd) {background: #cedace7a}
    .bodyttd{
        text-align: right;
        width: 100%;
        min-height: 50px;
        background: yellow
    }
    .isi{
        /* float:right */
    }
    </style>
</head>
<body>

    <img src="https://cdn.worldvectorlogo.com/logos/pertamina-logo-1.svg" style="width: 450px; position: fixed; right: -40%; top: 10px" alt="">

    <div class="judul">PT. PERTAMINA (PERSERO)</div>
    <div class="subjudul">LABORATORIUM TBBM JAKARTA GROUP - PLUMPANG</div>
    <p style="text-align: center; margin: 0">Jl. Yos Sudarso Jembatan I, Plumpang - Jakarta Utara 14230</p>
    <p style="text-align: center; margin: 0">Phone: +6221-43923156, Fax: +6221-43903367, E-mail: lab.plp@pertamina.com</p>
    
    <div style="width: 100%; height: 5px; background: black; margin-top: 10px"></div>
    <div style="width: 100%; height: 1px; background: black; margin-top: 5px; margin-bottom: 15px"></div>
    
    <h3 style="text-align: center; margin: 5px">DAFTAR BIAYA UJI</h3>

    <table style="width: 100%;" class="list">
    <thead style="background: #c9d6c9!important; text-align: center; padding: 3px">
        <tr>
            <th>No</th>
            <th>Parameter</th>
            <th>Test Method</th>
            <th>Harga</th>
        </tr>
    </thead>
    <tbody class="bodylist">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($k+1); ?></td>
            <td><?php echo e($d->parameter); ?></td>
            <td><?php echo e($d->metode); ?></td>
            <td>RP. <?php echo e(number_format($d->harga, 2, '.', ',')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="3">Total Biaya Uji</td>
            <td>RP. <?php echo e(number_format($total, 2, '.', ',')); ?></td>
        </tr>
    </tbody>
    </table>


</body>
</html><?php /**PATH /home/oeoes/Programming/Laravel Project/project/test-report-online-pertamina/resources/views/templates/report-biaya-uji.blade.php ENDPATH**/ ?>