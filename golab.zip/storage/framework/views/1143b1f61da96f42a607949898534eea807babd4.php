<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="main" class="layout-column flex">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ############ Content START-->
    <div id="content" class="flex ">
        <!-- ############ Main START-->
        <div>
            <div class="page-hero page-container " id="page-hero">
                <div class="padding d-flex">
                    <div class="page-title">
                        <h2 class="text-md text-highlight">Detail Process</h2>
                        <small class="text-muted">Record detail process</small>
                    </div>
                    <div class="flex"></div>
                </div>
            </div>
            <div class="page-content page-container" id="page-content">
                <div class="padding">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <strong>Detail Formulir</strong>
                                </div>
                                <div class="card-body">                                    
                                    <form>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">No Surat</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php echo e($detail->no_surat); ?>

                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Produk</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php echo e($detail->produk); ?>

                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Asal Sample</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php echo e($detail->asal_sample); ?>

                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Jenis Sample</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php echo e($detail->jenis_sample); ?>

                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Pengambil Sample</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php echo e($detail->pengambil_sample); ?>

                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Tanggal</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php echo e($detail->tgl); ?>

                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Waktu</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php echo e($detail->waktu); ?>

                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Accepted</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php if(!$detail->accepted): ?>
                                                 <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-light p-2">None</span>
                                                </span>
                                                <?php else: ?>
                                                <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-success p-2"><i data-feather='clock'></i> <?php echo e($detail->accepted); ?></span>
                                                    <span class="badge badge-success p-2"><i data-feather='user'></i> <?php echo e($detail->accepted_by); ?></span>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Sampling</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php if(!$detail->sampling): ?>
                                                 <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-light p-2">None</span>
                                                </span>
                                                <?php else: ?>
                                                <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-success p-2"><i data-feather='clock'></i> <?php echo e($detail->sampling); ?></span>
                                                    <span class="badge badge-success p-2"><i data-feather='user'></i> <?php echo e($detail->sampled_by); ?></span>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Arrived</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php if(!$detail->arrived): ?>
                                                 <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-light p-2">None</span>
                                                </span>
                                                <?php else: ?>
                                                <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-success p-2"><i data-feather='clock'></i> <?php echo e($detail->arrived); ?></span>
                                                    <span class="badge badge-success p-2"><i data-feather='user'></i> <?php echo e($detail->arrived_by); ?></span>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Testing</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php if(!$detail->testing): ?>
                                                 <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-light p-2">None</span>
                                                </span>
                                                <?php else: ?>
                                                <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-success p-2"><i data-feather='clock'></i> <?php echo e($detail->testing); ?></span>
                                                    <span class="badge badge-success p-2"><i data-feather='user'></i> <?php echo e($detail->tested_by); ?></span>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Released</label>
                                            <div class="col-sm-8 detail-form">
                                                <?php if(!$detail->released): ?>
                                                 <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-light p-2">None</span>
                                                </span>
                                                <?php else: ?>
                                                <span class="item-amount d-none d-sm-block text-sm">
                                                    <span class="badge badge-success p-2"><i data-feather='clock'></i> <?php echo e($detail->released); ?></span>
                                                    <span class="badge badge-success p-2"><i data-feather='user'></i> <?php echo e($detail->released_by); ?></span>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-4 col-form-label">Progress</label>
                                            <div class="col-sm-8 detail-form">
                                                <div class="line"></div>
                                                <div class="d-flex">
                                                    <?php if($detail->progress == 'waiting'): ?>
                                                    <div class="w-20 m-1 circle bg-progress-ac current" data-toggle="tooltip" title="" data-original-title="Waiting"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Accepted"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Sampling"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Arrived"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Testing"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Released"></div>
                                                    <?php elseif($detail->progress == 'accepted'): ?>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Waiting"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac current" data-toggle="tooltip" title="" data-original-title="Accepted"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Sampling"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Arrived"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Testing"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Released"></div>
                                                    <?php elseif($detail->progress == 'sampling'): ?>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Waiting"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Accepted"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac current" data-toggle="tooltip" title="" data-original-title="Sampling"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Arrived"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Testing"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Released"></div>
                                                    <?php elseif($detail->progress == 'arrived'): ?>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Waiting"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Accepted"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Sampling"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac current" data-toggle="tooltip" title="" data-original-title="Arrived"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Testing"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Released"></div>
                                                    <?php elseif($detail->progress == 'testing'): ?>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Waiting"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Accepted"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Sampling"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Arrived"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac current" data-toggle="tooltip" title="" data-original-title="Testing"></div>
                                                    <div class="w-20 m-1 circle bg-progress" data-toggle="tooltip" title="" data-original-title="Released"></div>
                                                    <?php else: ?>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Waiting"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Accepted"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Sampling"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Arrived"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Testing"></div>
                                                    <div class="w-20 m-1 circle bg-progress-ac" data-toggle="tooltip" title="" data-original-title="Released"></div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if(auth()->user()->role == 'lv2'): ?>
                                        <div class="form-group">
                                            <?php if($detail->progress == 'waiting'): ?>
                                            <a href="<?php echo e(route('details.change.state', ['id' => $detail->id, 'type' => 'accepted'])); ?>" class="btn btn-primary">Start</a>
                                            <?php elseif($detail->progress == 'accepted'): ?>
                                            <a href="<?php echo e(route('details.change.state', ['id' => $detail->id, 'type' => 'sampling'])); ?>" class="btn btn-primary">Take Sample</a>
                                            <?php elseif($detail->progress == 'sampling'): ?>
                                            <a href="<?php echo e(route('details.change.state', ['id' => $detail->id, 'type' => 'arrived'])); ?>" class="btn btn-primary">Done</a>
                                            <?php elseif($detail->progress == 'arrived'): ?>
                                            <a href="<?php echo e(route('details.change.state', ['id' => $detail->id, 'type' => 'testing'])); ?>" class="btn btn-primary">Testing</a>
                                            <?php elseif($detail->progress == 'testing'): ?>
                                            <a href="<?php echo e(route('details.change.state', ['id' => $detail->id, 'type' => 'released'])); ?>" class="btn btn-primary">Release Test</a>
                                            <?php else: ?>
                                            <div class="btn btn-primary">Completed <span><i data-feather='check-circle' class="ml-1"></i></span></div>
                                            <?php endif; ?>
                                        </div>
                                        <?php endif; ?>

                                    </form>

                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <img src="<?php echo e(asset('images/detail.svg')); ?>" alt="" style="max-width: 100%">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ############ Main END-->
    </div>
    <!-- ############ Content END-->
    <!-- ############ Footer START-->
    <div id="footer" class="page-footer hide">
        <div class="d-flex p-3">
            <span class="text-sm text-muted flex">&copy; Copyright. flatfull.com</span>
            <div class="text-sm text-muted">Version 1.0.3</div>
        </div>
    </div>
    <!-- ############ Footer END-->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oeoes/Programming/Laravel Project/project/test-report-online-pertamina/resources/views/app/a2/detail.blade.php ENDPATH**/ ?>