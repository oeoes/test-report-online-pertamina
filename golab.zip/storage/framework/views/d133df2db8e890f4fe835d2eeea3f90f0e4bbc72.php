<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="main" class="layout-column flex">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ############ Content START-->
    <div id="content" class="flex ">
        <!-- ############ Main START-->
        <div>
            <div class="page-hero page-container " id="page-hero">
                <div class="padding d-flex">
                    <div class="page-title">
                        <h2 class="text-md text-highlight">Completed Test Report</h2>
                        <small class="text-muted">List of Tests Need your Confirmation</small>
                    </div>
                    <div class="flex"></div>
                </div>
            </div>
            <div class="page-content page-container" id="page-content">
                <div class="padding">
                    <table id="table" class="table table-theme v-middle mt-3" data-plugin="bootstrapTable"
                        data-toolbar="#toolbar" data-search="true" data-search-align="left" data-show-export="true"
                        data-show-columns="true" data-detail-view="false" data-mobile-responsive="true"
                        data-pagination="true" data-page-list="[10, 25, 50, 100, ALL]">
                        <thead>
                            <tr>
                                <th data-sortable="true" data-field="owner">Owner</th>
                                <th data-sortable="true" data-field="produk">Produk</th>
                                <th data-sortable="true" data-field="produk">Issuer</th>
                                <th data-sortable="true" data-field="produk">Type</th>
                                <th data-sortable="true" data-field="produk">Print Request</th>
                                <th data-field="date"><span class="d-none d-sm-block">Released at</span></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(sizeof($print) < 1): ?>
                            <tr>
                                <td colspan="10" class="text-center">No data</td>
                            </tr>
                            <?php else: ?>
                            <?php $__currentLoopData = $print; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="" data-id="<?php echo e($p->id); ?>">
                                <td>
                                    <a>
                                        <span class="w-32 avatar gd-warning">
                                            <?php echo e(strtoupper($p->issuer[0])); ?>

                                        </span>
                                    </a>
                                </td>
                                <td class="flex">
                                    <a class="item-title text-color "><?php echo e(ucwords($p->produk)); ?></a>
                                    <div class="item-except text-muted text-sm h-1x">
                                        <?php echo e($p->issuer); ?>

                                    </div>
                                </td>
                                <td>
                                    <span class="item-amount d-none d-sm-block text-sm ">
                                        <?php echo e($p->issuer); ?>

                                    </span>
                                </td>
                                <td>
                                    <span class="item-amount d-none d-sm-block text-sm ">
                                        <?php echo e(strtoupper($p->type)); ?>

                                    </span>
                                </td>
                                <td>
                                    <span class="item-amount d-none d-sm-block text-sm ">
                                        <?php if($p->type == 'coq'): ?>
                                            <?php if($p->print_coq == 1): ?>
                                            <span class="badge badge-warning text-uppercase p-1">waiting</span>
                                            <?php else: ?>
                                            <span class="badge badge-info text-uppercase p-1">Approved</span>
                                            <?php endif; ?>
                                        <?php elseif($p->type == 'before'): ?>
                                            <?php if($p->print_before == 1): ?>
                                            <span class="badge badge-warning text-uppercase p-1">waiting</span>
                                            <?php else: ?>
                                            <span class="badge badge-info text-uppercase p-1">Approved</span>
                                            <?php endif; ?>
                                        <?php elseif($p->type == 'after'): ?>
                                            <?php if($p->print_after == 1): ?>
                                            <span class="badge badge-warning text-uppercase p-1">waiting</span>
                                            <?php else: ?>
                                            <span class="badge badge-info text-uppercase p-1">Approved</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if($p->print_distribution == 1): ?>
                                            <span class="badge badge-warning text-uppercase p-1">waiting</span>
                                            <?php else: ?>
                                            <span class="badge badge-info text-uppercase p-1">Approved</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="item-amount d-none d-sm-block text-sm [object Object]">
                                        <?php echo e($p->created_at->diffForHumans()); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="item-action dropdown">
                                        <a href="#" data-toggle="dropdown" class="text-muted">
                                            <i data-feather="more-vertical"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right bg-black" role="menu">
                                            <a href="<?php echo e(route('spesific-reports.request-print', ['flag' => $p->flag, 'type' => $p->type])); ?>" class="dropdown-item edit">
                                                Approve
                                            </a>
                                            <div class="dropdown-divider"></div>
                                            <a href="<?php echo e(route('reports.delete', $p->id)); ?>" class="dropdown-item trash">
                                                Delete item
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <!-- pagination -->
                    <?php echo e($print); ?>

                </div>
            </div>
        </div>
        <!-- ############ Main END-->
    </div>
    <!-- ############ Content END-->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oeoes/Programming/Laravel Project/project/test-report-online-pertamina/resources/views/app/maintainer/print-approval.blade.php ENDPATH**/ ?>