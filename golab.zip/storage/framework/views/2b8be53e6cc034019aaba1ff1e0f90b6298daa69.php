<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card border-0 shadow-sm p-3 mt-5">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" srcset="" style="max-width: 100%;">
                    <div class="h3 text-center mt-4">Join</div>
                    <span class="text-muted text-center">Join using invited email address</span>
                    <hr>
                    <form action="<?php echo e(route('user.join')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input name="email" type="email" class="form-control" placeholder="email..." required>
                        </div>

                        <div class="form-group">
                            <input type="submit" class="btn btn-primary btn-block" value="Join">
                        </div>
                    </form>
                    <?php if($errors->any()): ?>
                        <div class="display-1"><?php echo e($errors); ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oeoes/Programming/Laravel Project/project/test-report-online-pertamina/resources/views/auth/join.blade.php ENDPATH**/ ?>