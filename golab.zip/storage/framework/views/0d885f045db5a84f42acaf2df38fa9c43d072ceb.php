<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="main" class="layout-column flex">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ############ Content START-->
    <div id="content" class="flex ">
        <!-- ############ Main START-->
        <div>
            <div class="page-hero page-container " id="page-hero">
                <div class="padding d-flex">
                    <div class="page-title">
                        <h2 class="text-md text-highlight">Test Report</h2>
                        <small class="text-muted">Test report section</small>
                    </div>
                    <div class="flex"></div>
                </div>
            </div>
            <div class="page-content page-container" id="page-content">
                <div class="padding">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <strong>Reports</strong>
                                    <a href="<?php echo e(route('spesific-reports.print', ['id' => $title[0]->id, 'date' => $title[0]->date, 'type' => $type])); ?>" class="btn btn-sm btn-primary float-right circle pr-3 pl-3">Print</a>                                 

                                </div>
                                <div class="card-body"> 
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label">Produk</label>
                                        <div class="col-sm-4 detail-form">
                                            <?php echo e($title[0]->product_name); ?>

                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label">Released Date</label>
                                        <div class="col-sm-4 detail-form">
                                            <?php echo e($title[0]->date); ?>

                                        </div>
                                    </div>

                                    <table id="table" class="table table-theme v-middle mt-3" data-plugin="bootstrapTable"
                                        data-toolbar="#toolbar" data-search="true" data-search-align="left" data-show-export="true"
                                        data-show-columns="true" data-detail-view="false" data-mobile-responsive="true"
                                        data-pagination="true" data-page-list="[10, 25, 50, 100, ALL]">
                                        <thead>
                                            <tr>
                                                <th data-sortable="true" data-field="produk">Parameter</th>
                                                <th data-sortable="true" data-field="produk">Method test</th>
                                                <th data-sortable="true" data-field="produk">Unit</th>
                                                <th data-sortable="true" data-field="produk">Limitation Min</th>
                                                <th data-sortable="true" data-field="produk">Limitation Max</th>
                                                <th data-sortable="true" data-field="produk"></th>
                                                <th data-sortable="true" data-field="produk">Result</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- foreach -->
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="" data-id="17">
                                                <td>
                                                    <span class="item-amount d-none d-sm-block text-sm ">
                                                        <?php echo e($d->parameter); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="item-amount d-none d-sm-block text-sm">
                                                        <?php echo e($d->metode); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="item-amount d-none d-sm-block text-sm ">
                                                        <?php echo e($d->unit); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="item-amount d-none d-sm-block text-sm">
                                                        <?php echo e($d->limit_min); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="item-amount d-none d-sm-block text-sm">
                                                        <?php echo e($d->limit_max); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="item-amount d-none d-sm-block text-sm">
                                                        <span class="badge badge-info text-uppercase p-1"></span>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="item-amount d-none d-sm-block text-sm">
                                                        <?php echo e($value[$k]); ?>

                                                    </span>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <!-- endforeach -->
                                            
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- ############ Main END-->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oeoes/Programming/Laravel Project/project/test-report-online-pertamina/resources/views/app/a3/report.blade.php ENDPATH**/ ?>